# Sistema de Rastreabilidade de Calcados (SENAI Nova Serrana)

## Como rodar
1. `docker compose up --build -d`   (liga banco + API em http://localhost:8080)
2. `cd frontend`, `npm install`, `npm run dev`   (abre em http://localhost:5173)
3. Login: gestor@senai.com / 123456
