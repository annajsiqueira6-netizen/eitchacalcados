<template>
  <div class="dashboard-page">
    <!-- Cabeçalho Principal -->
    <div class="dash-header">
      <div>
        <h1>🔥 Dashboard Geral &bull; CWB sem Cheiro</h1>
        <p>Visão de alto nível sobre a linha de produção, lotes e rendimento das bancas.</p>
      </div>
      <div class="status-pill">
        <span class="pulse-dot"></span> Linha de Produção Ativa
      </div>
    </div>

    <!-- Cards de Indicadores Rápidos (Preenchendo a Tela) -->
    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-icon">📦</div>
        <div class="kpi-info">
          <span>Total de Lotes</span>
          <h3>24 Lotes</h3>
        </div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon">🏭</div>
        <div class="kpi-icon-bg"></div>
        <div class="kpi-info">
          <span>Bancas Ativas</span>
          <h3>6 Bancas</h3>
        </div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon">👟</div>
        <div class="kpi-info">
          <span>Pares Produzidos</span>
          <h3>2.400 Pares</h3>
        </div>
      </div>
      <div class="kpi-card">
        <div class="kpi-icon">⚡</div>
        <div class="kpi-info">
          <span>Eficiência do Ciclo</span>
          <h3>98.4%</h3>
        </div>
      </div>
    </div>

    <!-- Painel de Tabelas e Gráficos Visuais -->
    <div class="dash-content-grid">
      <!-- Tabela Principal de Lotes Recentes -->
      <div class="card table-card">
        <div class="card-title">
          <h3>📋 Lotes em Produção Recente</h3>
          <router-link to="/lotes" class="link-ver-todos">Ver Todos →</router-link>
        </div>
        <table>
          <thead>
            <tr>
              <th>Modelo</th>
              <th>Banca Responsável</th>
              <th>Pares</th>
              <th>Status</th>
              <th>Início</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="l in lotes" :key="l.id">
              <td><strong>{{ l.modelo }}</strong></td>
              <td>{{ l.banca?.nome || l.banca || 'Banca CWB 01' }}</td>
              <td>{{ l.quantidade }} pares</td>
              <td><span class="badge-status">{{ l.status || 'EM ANDAMENTO' }}</span></td>
              <td>10:45 AM</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Card de Desempenho e Alertas da Fábrica -->
      <div class="card side-panel">
        <h3>🔔 Alertas e Avisos da Fábrica</h3>
        <ul class="alerts-list">
          <li>
            <span class="alert-icon">✨</span>
            <div>
              <strong>Lote #108 Concluído</strong>
              <p>Banca Dona Rita finalizou a montagem.</p>
            </div>
          </li>
          <li>
            <span class="alert-icon">⚠️</span>
            <div>
              <strong>Aviso de Material</strong>
              <p>Estoque de solados cor-de-rosa em 15%.</p>
            </div>
          </li>
          <li>
            <span class="alert-icon">👤</span>
            <div>
              <strong>Novo Operador Adicionado</strong>
              <p>Atribuído à Banca CWB Principal.</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

const lotes = ref([])

async function carregar() {
  try {
    const res = await api.get('/lotes').catch(() => ({
      data: [
        { id: 1, modelo: 'Tênis Rosa PinkWalk', quantidade: 120, status: 'CRIADO', banca: { nome: 'Banca CWB Principal' } },
        { id: 2, modelo: 'Sapatilha Glamour Red', quantidade: 200, status: 'EM ANDAMENTO', banca: { nome: 'Banca Dona Rita' } },
        { id: 3, modelo: 'Bota Couro Chic', quantidade: 80, status: 'CONCLUÍDO', banca: { nome: 'Banca Três Irmãos' } }
      ]
    }))
    lotes.value = res.data
  } catch {
    lotes.value = [
      { id: 1, modelo: 'Tênis Rosa PinkWalk', quantidade: 120, status: 'CRIADO', banca: { nome: 'Banca CWB Principal' } }
    ]
  }
}

onMounted(carregar)
</script>

<style scoped>
.dashboard-page { display: flex; flex-direction: column; gap: 30px; }
.dash-header { display: flex; justify-content: space-between; align-items: center; }
.dash-header h1 { margin: 0; color: var(--text-primary); font-size: 1.8rem; font-weight: 800; }
.dash-header p { margin: 6px 0 0 0; color: var(--text-secondary); }

.status-pill {
  background: #ffffff;
  border: 1px solid var(--border-color);
  padding: 8px 18px;
  border-radius: 20px;
  font-weight: 700;
  font-size: 0.85rem;
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--accent-red);
  box-shadow: var(--shadow-deep);
}

.pulse-dot {
  width: 10px;
  height: 10px;
  background: var(--accent-red);
  border-radius: 50%;
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(230, 0, 35, 0.7); }
  70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(230, 0, 35, 0); }
  100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(230, 0, 35, 0); }
}

.kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; }

.kpi-card {
  background: white;
  padding: 24px;
  border-radius: 20px;
  border: 2px solid var(--border-color);
  display: flex;
  align-items: center;
  gap: 18px;
  box-shadow: var(--shadow-deep);
}

.kpi-icon { font-size: 2.2rem; background: #fff0f3; padding: 12px; border-radius: 16px; }
.kpi-info span { font-size: 0.85rem; font-weight: 700; color: var(--text-secondary); }
.kpi-info h3 { margin: 4px 0 0 0; font-size: 1.4rem; color: var(--accent-red); font-weight: 800; }

.dash-content-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 25px; }
@media (max-width: 1024px) { .dash-content-grid { grid-template-columns: 1fr; } }

.card-title { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
.link-ver-todos { color: var(--accent-red); font-weight: 700; text-decoration: none; font-size: 0.9rem; }

.badge-status {
  background: #fff0f3;
  color: var(--accent-red);
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 0.75rem;
  font-weight: 800;
  border: 1px solid var(--border-color);
}

.alerts-list { list-style: none; padding: 0; margin: 15px 0 0 0; display: flex; flex-direction: column; gap: 16px; }
.alerts-list li { display: flex; gap: 14px; background: #fff5f7; padding: 14px; border-radius: 14px; border: 1px solid var(--border-color); }
.alert-icon { font-size: 1.4rem; }
.alerts-list strong { font-size: 0.9rem; color: var(--text-primary); }
.alerts-list p { margin: 2px 0 0 0; font-size: 0.8rem; color: var(--text-secondary); }
</style>