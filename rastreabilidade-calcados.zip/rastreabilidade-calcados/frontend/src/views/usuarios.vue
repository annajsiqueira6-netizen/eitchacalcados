<template>
  <div class="usuarios-page">
    <!-- Cabeçalho Principal -->
    <div class="header-banner">
      <div>
        <h1>👑 Gestão de Utilizadores &bull; Eitchá Calçados</h1>
        <p>Cadastre e gira a equipa de gestores, operadores de banca e fiscais da loja.</p>
      </div>
      <div class="brand-badge">
        <span>👠 Eitchá Calçados Team</span>
      </div>
    </div>

    <!-- Indicadores de Equipa -->
    <div class="team-stats">
      <div class="stat-card">
        <span class="stat-icon">👥</span>
        <div>
          <span class="stat-label">Total Cadastrados</span>
          <p class="stat-value">{{ usuarios.length }} Utilizadores</p>
        </div>
      </div>
      <div class="stat-card">
        <span class="stat-icon">🟢</span>
        <div>
          <span class="stat-label">Sessões Ativas</span>
          <p class="stat-value">1 Online Agora</p>
        </div>
      </div>
      <div class="stat-card">
        <span class="stat-icon">🔑</span>
        <div>
          <span class="stat-label">Nível de Acesso</span>
          <p class="stat-value">Administrador Geral</p>
        </div>
      </div>
    </div>

    <div class="content-grid">
      <!-- Formulario de Cadastro Elegante -->
      <div class="card form-card">
        <div class="card-header-custom">
          <h2>✨ Novo Integrante</h2>
          <p>Preencha os dados do novo membro da equipa.</p>
        </div>

        <form @submit.prevent="salvarUsuario" class="user-form">
          <div class="form-group">
            <label>Nome Completo</label>
            <input v-model="f.nome" placeholder="Ex: Maria Natyele" required />
          </div>

          <div class="form-group">
            <label>E-mail Corporativo</label>
            <input v-model="f.email" type="email" placeholder="ex: maria@eitchacalçados.com" required />
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Cargo / Perfil</label>
              <select v-model="f.perfil">
                <option value="GESTOR">👑 Gestor de Fábrica</option>
                <option value="OPERADOR">🧵 Operador de Banca</option>
                <option value="INSPETOR">🔍 Inspetor de Qualidade</option>
              </select>
            </div>

            <div class="form-group">
              <label>Palavra-passe Inicial</label>
              <input v-model="f.senha" type="password" placeholder="••••••••" required />
            </div>
          </div>

          <button type="submit" class="btn-primary btn-block">
            Cadastrar na Eitchá Calçados 🔥
          </button>
        </form>

        <transition name="fade">
          <div v-if="mensagem" class="alert-success">
            <span>🎉 {{ mensagem }}</span>
          </div>
        </transition>
      </div>

      <!-- Tabela / Lista Estilizada da Equipa -->
      <div class="card table-card">
        <div class="card-header-custom">
          <h2>👥 Equipa Ativa na Eitchá Calçados</h2>
          <p>Membros com acesso permitido ao sistema de rastreio.</p>
        </div>

        <div class="user-list">
          <div v-for="u in usuarios" :key="u.id" class="user-item">
            <div class="avatar-circle">
              {{ u.nome.charAt(0).toUpperCase() }}
            </div>
            <div class="user-details">
              <strong>{{ u.nome }}</strong>
              <small>{{ u.email }}</small>
            </div>
            <div class="user-meta">
              <span class="role-pill" :class="u.perfil.toLowerCase()">{{ u.perfil }}</span>
              <span class="status-dot" title="Ativo no sistema"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const mensagem = ref('')
const f = ref({ nome: '', email: '', perfil: 'OPERADOR', senha: '' })

const usuarios = ref([
  { id: 1, nome: 'Gestor SENAI', email: 'admin@eitcha.com', perfil: 'GESTOR' },
  { id: 2, nome: 'Maria Silva', email: 'maria@eitcha.com', perfil: 'OPERADOR' },
  { id: 3, nome: 'Ana Natyele', email: 'natyele@eitcha.com', perfil: 'INSPETOR' }
])

function salvarUsuario() {
  usuarios.value.unshift({
    id: Date.now(),
    nome: f.value.nome,
    email: f.value.email,
    perfil: f.value.perfil
  })
  mensagem.value = 'Utilizador cadastrado com sucesso na Eitchá Calçados!'
  f.value = { nome: '', email: '', perfil: 'OPERADOR', senha: '' }
  setTimeout(() => mensagem.value = '', 3500)
}
</script>

<style scoped>
.usuarios-page {
  display: flex;
  flex-direction: column;
  gap: 25px;
}

.header-banner {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-banner h1 {
  margin: 0;
  font-size: 1.8rem;
  font-weight: 900;
  color: var(--text-primary);
}

.header-banner p {
  margin: 5px 0 0 0;
  color: var(--text-secondary);
}

.brand-badge {
  background: white;
  border: 2px solid var(--border-color);
  padding: 10px 20px;
  border-radius: 20px;
  font-weight: 800;
  color: var(--accent-red);
  box-shadow: var(--shadow-deep);
}

/* CARDS DE ESTATÍSTICAS DA EQUIPA */
.team-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
}

.stat-card {
  background: white;
  border-radius: 20px;
  padding: 20px;
  border: 2px solid var(--border-color);
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: var(--shadow-deep);
}

.stat-icon {
  font-size: 2rem;
  background: #fff0f3;
  padding: 10px;
  border-radius: 14px;
}

.stat-label {
  font-size: 0.8rem;
  font-weight: 700;
  color: var(--text-secondary);
}

.stat-value {
  margin: 2px 0 0 0;
  font-size: 1.1rem;
  font-weight: 800;
  color: var(--accent-red);
}

/* LAYOUT PRINCIPAL */
.content-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 25px;
}

@media (max-width: 960px) {
  .content-grid {
    grid-template-columns: 1fr;
  }
}

.card-header-custom {
  margin-bottom: 20px;
  border-bottom: 1px solid var(--border-color);
  padding-bottom: 12px;
}

.card-header-custom h2 {
  margin: 0;
  color: var(--accent-red);
  font-size: 1.3rem;
  font-weight: 800;
}

.card-header-custom p {
  margin: 4px 0 0 0;
  color: var(--text-secondary);
  font-size: 0.85rem;
}

.user-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-group label {
  font-weight: 700;
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 15px;
}

.btn-block {
  width: 100%;
  margin-top: 10px;
}

.alert-success {
  margin-top: 18px;
  background: #d1fae5;
  border: 1px solid #10b981;
  color: #047857;
  padding: 12px;
  border-radius: 12px;
  font-weight: 700;
  text-align: center;
  font-size: 0.9rem;
}

/* LISTA ESTILIZADA DE UTILIZADORES */
.user-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.user-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  background: #fff5f7;
  border-radius: 16px;
  border: 1px solid var(--border-color);
  transition: all 0.25s ease;
}

.user-item:hover {
  transform: translateX(4px);
  background: white;
  box-shadow: 0 4px 15px rgba(230, 0, 35, 0.1);
}

.avatar-circle {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ff3366, #e60023);
  color: white;
  font-weight: 900;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.1rem;
  box-shadow: 0 4px 10px rgba(230, 0, 35, 0.25);
}

.user-details {
  display: flex;
  flex-direction: column;
  flex: 1;
  margin-left: 15px;
}

.user-details strong {
  color: var(--text-primary);
  font-size: 0.95rem;
}

.user-details small {
  color: var(--text-secondary);
  font-size: 0.8rem;
}

.user-meta {
  display: flex;
  align-items: center;
  gap: 12px;
}

.role-pill {
  padding: 6px 12px;
  border-radius: 10px;
  font-size: 0.75rem;
  font-weight: 800;
  text-transform: uppercase;
}

.role-pill.gestor { background: #ffe4e6; color: #e60023; }
.role-pill.operador { background: #e0f2fe; color: #0284c7; }
.role-pill.inspetor { background: #fef3c7; color: #d97706; }

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 8px rgba(16, 185, 129, 0.6);
}

.fade-enter-active, .fade-leave-active { transition: opacity 0.3s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }
</style>