<template>
  <div class="leitor-page">
    <!-- Cabeçalho Principal -->
    <div class="header-banner">
      <div>
        <h1>📷 Leitor de QR Code &bull; Eitchá Calçados</h1>
        <p>Aponte a câmara para a etiqueta do lote ou digite o código para validar a rastreabilidade.</p>
      </div>
      <div class="brand-badge">
        <span>⚡ Scanner Ativo</span>
      </div>
    </div>

    <!-- Indicadores Rápidos do Scanner -->
    <div class="scanner-stats">
      <div class="stat-card">
        <span class="stat-icon">📷</span>
        <div>
          <span class="stat-label">Estado da Câmara</span>
          <p class="stat-value" :class="{ 'text-active': cameraAtiva }">
            {{ cameraAtiva ? 'Digitalizando...' : 'Aguardando Ativação' }}
          </p>
        </div>
      </div>
      <div class="stat-card">
        <span class="stat-icon">✅</span>
        <div>
          <span class="stat-label">Última Leitura</span>
          <p class="stat-value">{{ ultimoLoteLido ? ultimoLoteLido.modelo : 'Nenhuma' }}</p>
        </div>
      </div>
      <div class="stat-card">
        <span class="stat-icon">🔍</span>
        <div>
          <span class="stat-label">Precisão do Laser</span>
          <p class="stat-value">100% HD</p>
        </div>
      </div>
    </div>

    <!-- Painel Duplo: Scanner de Câmara + Validação Manual -->
    <div class="scanner-grid">
      <!-- Simulação de Câmara / Scanner Animado -->
      <div class="card scanner-card">
        <div class="card-header-custom">
          <h2>📸 Scanner de Etiquetas</h2>
          <p>Aponte a etiqueta do sapato para o enquadramento.</p>
        </div>

        <div class="viewfinder-container">
          <div class="viewfinder" :class="{ scanning: cameraAtiva }">
            <!-- Miras dos Cantos -->
            <span class="corner top-left"></span>
            <span class="corner top-right"></span>
            <span class="corner bottom-left"></span>
            <span class="corner bottom-right"></span>

            <!-- Linha de Laser Animada -->
            <div v-if="cameraAtiva" class="laser-line"></div>

            <div v-if="!cameraAtiva" class="viewfinder-placeholder">
              <span class="camera-icon">📷</span>
              <p>Clique no botão abaixo para ligar a câmara de leitura</p>
            </div>
            <div v-else class="viewfinder-active">
              <span class="scanning-badge">Buscando QR Code na linha...</span>
            </div>
          </div>
        </div>

        <div class="action-buttons">
          <button v-if="!cameraAtiva" @click="ligarCamera" class="btn-primary btn-block">
            Ligar Câmara 🔥
          </button>
          <button v-else @click="desligarCamera" class="btn-secondary btn-block">
            Desligar Câmara 🛑
          </button>
        </div>
      </div>

      <!-- Leitura Manual por Código -->
      <div class="card manual-card">
        <div class="card-header-custom">
          <h2>⌨️ Leitura Manual de Código</h2>
          <p>Sem câmara disponível? Digite o código ou ID do lote.</p>
        </div>

        <form @submit.prevent="processarCodigoManual" class="manual-form">
          <div class="form-group">
            <label>Código do Lote / QR Code</label>
            <input 
              v-model="codigoManual" 
              placeholder="Ex: LOTE-108 ou Tênis Rosa" 
              required 
            />
          </div>

          <button type="submit" class="btn-primary btn-block" :disabled="processando">
            <span v-if="!processando">Validar Lote na Eitchá Calçados 🔍</span>
            <span v-else>A processar leitura...</span>
          </button>
        </form>

        <p v-if="erro" class="alert-error">{{ erro }}</p>

        <!-- Histórico Rápido de Leituras -->
        <div class="recent-scans">
          <h3>🕒 Leituras Recentes</h3>
          <ul>
            <li v-for="(h, idx) in historico" :key="idx">
              <span>{{ h.hora }} - <strong>{{ h.codigo }}</strong></span>
              <span class="status-pill-sm">VALIDADO</span>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- POP-UP MODAL DE SUCESSO DA LEITURA -->
    <div v-if="modalSucesso" class="modal-overlay" @click.self="modalSucesso = false">
      <div class="modal-card">
        <button class="close-modal" @click="modalSucesso = false">✕</button>
        <div class="modal-header">
          <span class="success-icon">✨</span>
          <h2>Lote Identificado com Sucesso!</h2>
          <p>Rastreabilidade confirmada no sistema da <strong>Eitchá Calçados</strong>.</p>
        </div>

        <div class="modal-body" v-if="ultimoLoteLido">
          <div class="lote-info-box">
            <h3>{{ ultimoLoteLido.modelo }}</h3>
            <p><strong>Banca:</strong> {{ ultimoLoteLido.banca?.nome || ultimoLoteLido.banca || 'Banca CWB Principal' }}</p>
            <p><strong>Quantidade:</strong> {{ ultimoLoteLido.quantidade }} pares</p>
            <p><strong>Estado:</strong> <span class="badge-status">{{ ultimoLoteLido.status || 'CONCLUÍDO' }}</span></p>
          </div>
        </div>

        <div class="modal-footer">
          <button @click="modalSucesso = false" class="btn-primary btn-block">
            Confirmar e Continuar Leitura 🚀
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const cameraAtiva = ref(false)
const codigoManual = ref('')
const erro = ref('')
const processando = ref(false)
const modalSucesso = ref(false)
const ultimoLoteLido = ref(null)

const historico = ref([
  { codigo: 'Tênis Rosa PinkWalk', hora: '11:20 AM' },
  { codigo: 'Sapatilha Glamour Red', hora: '10:45 AM' }
])

function ligarCamera() {
  cameraAtiva.value = true
  erro.value = ''
}

function desligarCamera() {
  cameraAtiva.value = false
}

function processarCodigoManual() {
  if (!codigoManual.value) return
  erro.value = ''
  processando.value = true

  setTimeout(() => {
    ultimoLoteLido.value = {
      modelo: codigoManual.value,
      quantidade: 150,
      banca: 'Banca CWB Principal',
      status: 'EM PROCESSAMENTO'
    }

    const agora = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    historico.value.unshift({ codigo: codigoManual.value, hora: agora })

    processando.value = false
    modalSucesso.value = true
    codigoManual.value = ''
  }, 600)
}
</script>

<style scoped>
.leitor-page {
  display: flex;
  flex-direction: column;
  gap: 25px;
}

.header-banner {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-banner h1 {
  margin: 0;
  font-size: 1.8rem;
  font-weight: 900;
  color: var(--text-primary);
}

.header-banner p {
  margin: 5px 0 0 0;
  color: var(--text-secondary);
}

.brand-badge {
  background: white;
  border: 2px solid var(--border-color);
  padding: 10px 20px;
  border-radius: 20px;
  font-weight: 800;
  color: var(--accent-red);
  box-shadow: var(--shadow-deep);
}

/* CARDS DE ESTATÍSTICAS */
.scanner-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
}

.stat-card {
  background: white;
  border-radius: 20px;
  padding: 20px;
  border: 2px solid var(--border-color);
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: var(--shadow-deep);
}

.stat-icon {
  font-size: 2rem;
  background: #fff0f3;
  padding: 10px;
  border-radius: 14px;
}

.stat-label {
  font-size: 0.8rem;
  font-weight: 700;
  color: var(--text-secondary);
}

.stat-value {
  margin: 2px 0 0 0;
  font-size: 1.1rem;
  font-weight: 800;
  color: var(--text-primary);
}

.stat-value.text-active {
  color: var(--accent-red);
}

/* LAYOUT PRINCIPAL DO SCANNER */
.scanner-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 25px;
}

@media (max-width: 960px) {
  .scanner-grid {
    grid-template-columns: 1fr;
  }
}

.card-header-custom {
  margin-bottom: 20px;
  border-bottom: 1px solid var(--border-color);
  padding-bottom: 12px;
}

.card-header-custom h2 {
  margin: 0;
  color: var(--accent-red);
  font-size: 1.3rem;
  font-weight: 800;
}

.card-header-custom p {
  margin: 4px 0 0 0;
  color: var(--text-secondary);
  font-size: 0.85rem;
}

/* MIRA / ENQUADRAMENTO DO SCANNER */
.viewfinder-container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 20px 0;
}

.viewfinder {
  width: 100%;
  max-width: 320px;
  height: 240px;
  background: #1e050e;
  border-radius: 20px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: inset 0 0 20px rgba(0, 0, 0, 0.6);
}

.corner {
  position: absolute;
  width: 24px;
  height: 24px;
  border: 4px solid var(--accent-red);
}

.top-left { top: 15px; left: 15px; border-right: none; border-bottom: none; border-radius: 8px 0 0 0; }
.top-right { top: 15px; right: 15px; border-left: none; border-bottom: none; border-radius: 0 8px 0 0; }
.bottom-left { bottom: 15px; left: 15px; border-right: none; border-top: none; border-radius: 0 0 0 8px; }
.bottom-right { bottom: 15px; right: 15px; border-left: none; border-top: none; border-radius: 0 0 8px 0; }

.laser-line {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 3px;
  background: linear-gradient(90deg, transparent, #ff3366, #e60023, transparent);
  box-shadow: 0 0 15px #e60023;
  animation: scanLaser 2s infinite ease-in-out;
}

@keyframes scanLaser {
  0% { top: 10%; }
  50% { top: 90%; }
  100% { top: 10%; }
}

.viewfinder-placeholder {
  text-align: center;
  color: #ffb3c1;
  padding: 20px;
}

.camera-icon {
  font-size: 2.5rem;
}

.viewfinder-placeholder p {
  font-size: 0.85rem;
  margin-top: 8px;
  opacity: 0.8;
}

.scanning-badge {
  color: #ff3366;
  font-weight: bold;
  font-size: 0.9rem;
  animation: blink 1.2s infinite;
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}

.btn-block {
  width: 100%;
  margin-top: 10px;
}

.btn-secondary {
  background: #3d0a1b;
  color: white;
  border: none;
  padding: 14px;
  border-radius: 14px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  background: var(--accent-red);
}

/* FORMULÁRIO MANUAL */
.manual-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.form-group label {
  font-weight: 700;
  font-size: 0.85rem;
  color: var(--text-secondary);
}

.alert-error {
  margin-top: 15px;
  background: rgba(230, 0, 35, 0.15);
  border: 1px solid var(--accent-red);
  color: var(--accent-red);
  padding: 12px;
  border-radius: 12px;
  font-weight: 700;
  text-align: center;
}

.recent-scans {
  margin-top: 25px;
  border-top: 1px solid var(--border-color);
  padding-top: 15px;
}

.recent-scans h3 {
  font-size: 0.95rem;
  color: var(--text-primary);
  margin-bottom: 12px;
}

.recent-scans ul {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.recent-scans li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #fff5f7;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 0.85rem;
  border: 1px solid var(--border-color);
}

.status-pill-sm {
  background: #d1fae5;
  color: #047857;
  font-size: 0.7rem;
  font-weight: 800;
  padding: 4px 8px;
  border-radius: 6px;
}

/* POP-UP MODAL */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(61, 10, 27, 0.5);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
}

.modal-card {
  background: white;
  border-radius: 28px;
  padding: 35px;
  width: 90%;
  max-width: 440px;
  text-align: center;
  position: relative;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
  border: 2px solid var(--border-color);
  animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

@keyframes popIn {
  from { opacity: 0; transform: scale(0.85); }
  to { opacity: 1; transform: scale(1); }
}

.close-modal {
  position: absolute;
  top: 20px;
  right: 20px;
  background: #fff0f3;
  border: none;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  cursor: pointer;
  font-weight: bold;
}

.success-icon {
  font-size: 3rem;
}

.modal-header h2 {
  margin: 10px 0 5px 0;
  color: var(--accent-red);
}

.modal-header p {
  margin: 0;
  color: var(--text-secondary);
  font-size: 0.85rem;
}

.lote-info-box {
  background: #fff0f3;
  padding: 18px;
  border-radius: 16px;
  border: 1px solid var(--border-color);
  margin: 20px 0;
  text-align: left;
}

.lote-info-box h3 {
  margin: 0 0 10px 0;
  color: var(--text-primary);
}

.lote-info-box p {
  margin: 6px 0;
  font-size: 0.9rem;
  color: var(--text-secondary);
}

.badge-status {
  background: var(--accent-red);
  color: white;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 800;
}

.modal-footer {
  margin-top: 10px;
}
</style>