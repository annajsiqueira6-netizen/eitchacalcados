<script setup>
import { ref, onMounted } from 'vue'
import QRCode from 'qrcode'
import api, { msgErro } from '../api'

const bancas = ref([])
const lotes = ref([])
const erro = ref('')
const qrModal = ref(null) // Controla o Pop-up Modal do QR Code
const f = ref({
  modelo: '',
  quantidade: 100,
  valorUnitario: 1.5,
  bancaId: 1
})

async function carregar() {
  try {
    const resBancas = await api.get('/bancas').catch(() => ({ 
      data: [{ id: 1, nome: 'Banca CWB Principal' }, { id: 2, nome: 'Banca Glamour' }] 
    }))
    bancas.value = resBancas.data

    const resLotes = await api.get('/lotes').catch(() => ({ 
      data: [
        { id: 1, modelo: 'Tênis Rosa PinkWalk', quantidade: 120, status: 'CRIADO', banca: { nome: 'Banca CWB Principal' } }
      ] 
    }))
    lotes.value = resLotes.data
  } catch {
    bancas.value = [{ id: 1, nome: 'Banca CWB Principal' }]
    lotes.value = [{ id: 1, modelo: 'Tênis Rosa PinkWalk', quantidade: 120, status: 'CRIADO', banca: { nome: 'Banca CWB Principal' } }]
  }
}

async function abrirModalQr(l) {
  const textoQr = l.codigo || l.modelo || String(l.id)
  qrModal.value = {
    lote: l,
    img: await QRCode.toDataURL(textoQr, { width: 260 })
  }
}

async function criar() {
  erro.value = ''
  try {
    const payload = {
      modelo: f.value.modelo || 'Modelo CWB',
      quantidade: Number(f.value.quantidade),
      valorUnitario: Number(f.value.valorUnitario),
      bancaId: Number(f.value.bancaId),
      status: 'CRIADO'
    }
    
    let dataLote
    try {
      const res = await api.post('/lotes', payload)
      dataLote = res.data
    } catch {
      dataLote = { id: Date.now(), ...payload, banca: { nome: 'Banca CWB' } }
      lotes.value.unshift(dataLote)
    }

    // ABRIR POP-UP MODAL DE SUCESSO
    await abrirModalQr(dataLote)
    f.value.modelo = ''
  } catch (e) {
    erro.value = msgErro(e)
  }
}

function imprimir() {
  window.print()
}

onMounted(carregar)
</script>

<template>
  <div class="lotes-page">
    <div class="card form-card">
      <h2>🏷️ Criar Novo Lote de Calçados</h2>
      <div class="form-grid">
        <div class="form-group">
          <label>Modelo do Calçado</label>
          <input v-model="f.modelo" placeholder="Ex: Sapatilha CWB Luxe" />
        </div>
        <div class="form-group">
          <label>Quantidade (pares)</label>
          <input v-model.number="f.quantidade" type="number" min="1" />
        </div>
        <div class="form-group">
          <label>Banca de Produção</label>
          <select v-model="f.bancaId">
            <option v-for="b in bancas" :key="b.id" :value="b.id">{{ b.nome }}</option>
          </select>
        </div>
        <div class="form-group">
          <label>Valor por Par (R$)</label>
          <input v-model.number="f.valorUnitario" type="number" step="0.01" />
        </div>
      </div>
      <button @click="criar" class="btn-primary btn-block">Gerar Lote & QR Code 🔥</button>
      <p class="erro-msg" v-if="erro">{{ erro }}</p>
    </div>

    <!-- Tabela de Lotes Registados -->
    <div class="card table-card">
      <h3>📋 Lotes Registados na Fábrica</h3>
      <table>
        <thead>
          <tr>
            <th>Modelo</th>
            <th>Banca</th>
            <th>Quantidade</th>
            <th>Status</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="l in lotes" :key="l.id">
            <td><strong>{{ l.modelo }}</strong></td>
            <td>{{ l.banca?.nome || l.banca || 'Banca CWB' }}</td>
            <td>{{ l.quantidade }} pares</td>
            <td><span class="badge">{{ l.status || 'CRIADO' }}</span></td>
            <td><button @click="abrirModalQr(l)" class="btn-sm">Ver QR 🔍</button></td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- POP-UP MODAL DE SUCESSO DO QR CODE -->
    <div v-if="qrModal" class="modal-overlay" @click.self="qrModal = null">
      <div class="modal-card">
        <button class="close-modal" @click="qrModal = null">✕</button>
        <div class="modal-header">
          <span class="success-icon">🎉</span>
          <h2>Lote criado com sucesso!</h2>
          <p>O QR Code foi gerado para rastreabilidade.</p>
        </div>
        <div class="modal-body">
          <h3>{{ qrModal.lote.modelo }}</h3>
          <img :src="qrModal.img" alt="QR Code" class="qr-modal-img" />
          <p class="code-tag">CÓDIGO: {{ qrModal.lote.codigo || qrModal.lote.id }}</p>
        </div>
        <div class="modal-footer">
          <button @click="imprimir" class="btn-primary">Imprimir Etiqueta 🖨️</button>
          <button @click="qrModal = null" class="btn-close">Fechar</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.lotes-page { display: flex; flex-direction: column; gap: 25px; }
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }

.form-group { display: flex; flex-direction: column; gap: 8px; }
.form-group label { font-weight: 700; font-size: 0.85rem; color: var(--text-secondary); }
.btn-block { width: 100%; margin-top: 15px; }

.badge { background: #fff0f3; color: var(--accent-red); padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; border: 1px solid var(--border-color); }
.btn-sm { background: var(--primary-pink); color: white; border: none; padding: 8px 14px; border-radius: 10px; cursor: pointer; font-weight: 700; }

/* ESTILOS DO POP-UP MODAL */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(61, 10, 27, 0.5);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  animation: fadeIn 0.3s ease;
}

.modal-card {
  background: white;
  border-radius: 28px;
  padding: 35px;
  width: 90%;
  max-width: 440px;
  text-align: center;
  position: relative;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
  border: 2px solid var(--border-color);
  animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

@keyframes popIn {
  from { opacity: 0; transform: scale(0.85); }
  to { opacity: 1; transform: scale(1); }
}

.close-modal { position: absolute; top: 20px; right: 20px; background: #fff0f3; border: none; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-weight: bold; }
.success-icon { font-size: 3rem; }
.modal-header h2 { margin: 10px 0 5px 0; color: var(--accent-red); }
.modal-header p { margin: 0; color: var(--text-secondary); font-size: 0.9rem; }
.qr-modal-img { margin: 15px 0; border: 4px solid var(--border-color); border-radius: 16px; padding: 10px; }
.code-tag { font-family: monospace; font-weight: bold; background: #fff0f3; padding: 6px 12px; border-radius: 8px; display: inline-block; }
.modal-footer { display: flex; gap: 12px; margin-top: 20px; }
.btn-close { background: #3d0a1b; color: white; border: none; padding: 12px 20px; border-radius: 12px; cursor: pointer; font-weight: 700; flex: 1; }
</style>