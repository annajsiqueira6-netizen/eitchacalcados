import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api/',
})

// Injeta o token em todas as requisições
api.interceptors.request.use(cfg => {
  const t = localStorage.getItem('token')
  if (t) {
    cfg.headers.Authorization = 'Bearer ' + t
  }
  return cfg
})

// TRATAMENTO BLINDADO: Removemos o redirecionamento forçado para evitar loops
api.interceptors.response.use(
  r => r,
  e => {
    if (e.response && e.response.status === 401) {
      console.warn('Aviso: Token não validado pelo backend, operando em modo livre.')
    }
    return Promise.reject(e)
  }
)

export const msgErro = e => e.response?.data?.erro || e.response?.data?.message || 'Erro ao comunicar com o servidor'

export default api