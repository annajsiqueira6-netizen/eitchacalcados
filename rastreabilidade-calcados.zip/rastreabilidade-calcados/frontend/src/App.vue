<template>
  <div id="app" class="app-root">
    <!-- Botão Retrátil da Flecha no Canto Superior Esquerdo -->
    <div 
      v-if="$route.path !== '/login'" 
      class="drawer-trigger-left" 
      :class="{ open: menuAberto }" 
      @click="toggleMenu"
      title="Abrir Menu de Navegação"
    >
      <span class="trigger-icon">▶</span>
      <span class="trigger-text">MENU</span>
    </div>

    <!-- Gaveta Retrátil Lateral Esquerda -->
    <aside v-if="$route.path !== '/login'" class="drawer-menu-left" :class="{ open: menuAberto }">
      <div class="drawer-header">
        <span class="drawer-logo">👠✨</span>
        <div class="drawer-title">
          <h2>CWB sem Cheiro</h2>
          <p>Painel de Rastreabilidade</p>
        </div>
        <button class="close-btn" @click="menuAberto = false">✕</button>
      </div>

      <nav class="drawer-nav">
        <router-link to="/" class="drawer-link" @click="menuAberto = false">
          <span class="icon">📊</span> Dashboard Principal
        </router-link>
        <router-link to="/lotes" class="drawer-link" @click="menuAberto = false">
          <span class="icon">🏷️</span> Lotes & QR Code
        </router-link>
        <router-link to="/usuarios" class="drawer-link" @click="menuAberto = false">
          <span class="icon">👤</span> Registar Utilizador
        </router-link>
        <router-link to="/leitor" class="drawer-link" @click="menuAberto = false">
          <span class="icon">📷</span> Leitor QR
        </router-link>
      </nav>

      <div class="drawer-footer">
        <button @click="sair" class="btn-sair-drawer">
          🚪 Sair do Sistema
        </button>
      </div>
    </aside>

    <!-- Overlay de Fundo -->
    <div 
      v-if="$route.path !== '/login' && menuAberto" 
      class="drawer-overlay" 
      @click="menuAberto = false"
    ></div>

    <!-- Workspace Principal -->
    <main class="main-workspace" :class="{ 'full-page': $route.path === '/login' }">
      <router-view v-slot="{ Component }">
        <transition name="page-fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </router-view>
    </main>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const menuAberto = ref(false)

function toggleMenu() {
  menuAberto.value = !menuAberto.value
}

function sair() {
  menuAberto.value = false
  localStorage.clear()
  router.push('/login')
}
</script>

<style>
:root {
  --bg-main: #fff0f3;
  --card-bg: #ffffff;
  --text-primary: #3d0a1b;
  --text-secondary: #8c3f5d;
  --border-color: #ffd1dc;
  --primary-pink: #ff4d88;
  --accent-red: #e60023;
  --shadow-deep: 0 15px 35px rgba(230, 0, 35, 0.12);
}

body {
  margin: 0;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  background-color: var(--bg-main);
  color: var(--text-primary);
  overflow-x: hidden;
}

.app-root {
  min-height: 100vh;
  display: flex;
  position: relative;
}

.main-workspace {
  flex: 1;
  padding: 40px;
  padding-top: 70px; /* Garante espaço para o botão superior */
  max-width: 1500px;
  margin: 0 auto;
  width: 100%;
}

.main-workspace.full-page {
  padding: 0;
  max-width: 100%;
}

/* BOTÃO DA FLECHA NO CANTO SUPERIOR ESQUERDO */
.drawer-trigger-left {
  position: fixed;
  left: 0;
  top: 20px;
  background: linear-gradient(135deg, #ff3366, #e60023);
  color: white;
  padding: 10px 18px;
  border-radius: 0 20px 20px 0;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  z-index: 1001;
  box-shadow: 4px 4px 20px rgba(230, 0, 35, 0.35);
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  font-weight: 800;
  font-size: 0.85rem;
}

.drawer-trigger-left:hover {
  padding-left: 24px;
  background: linear-gradient(135deg, #e60023, #b3001b);
}

.drawer-trigger-left.open .trigger-icon {
  transform: rotate(180deg);
}

/* GAVETA LATERAL ESQUERDA */
.drawer-menu-left {
  position: fixed;
  top: 0;
  left: -340px;
  width: 320px;
  height: 100vh;
  background: rgba(255, 255, 255, 0.96);
  backdrop-filter: blur(20px);
  box-shadow: 10px 0 40px rgba(0, 0, 0, 0.15);
  border-right: 2px solid var(--border-color);
  z-index: 1002;
  display: flex;
  flex-direction: column;
  transition: left 0.4s cubic-bezier(0.16, 1, 0.3, 1);
}

.drawer-menu-left.open {
  left: 0;
}

.drawer-header {
  padding: 30px 25px;
  background: linear-gradient(135deg, #ff3366 0%, #e60023 100%);
  color: white;
  display: flex;
  align-items: center;
  gap: 15px;
  position: relative;
}

.drawer-logo { font-size: 2.2rem; }
.drawer-title h2 { margin: 0; font-size: 1.2rem; font-weight: 800; }
.drawer-title p { margin: 2px 0 0 0; font-size: 0.8rem; opacity: 0.85; }

.close-btn {
  position: absolute;
  top: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  width: 32px;
  height: 32px;
  border-radius: 50%;
  cursor: pointer;
}

.drawer-nav {
  padding: 30px 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.drawer-link {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 16px 20px;
  color: var(--text-primary);
  text-decoration: none;
  font-weight: 700;
  border-radius: 16px;
  background: #fff5f7;
  border: 1px solid var(--border-color);
  transition: all 0.3s ease;
}

.drawer-link:hover, .drawer-link.router-link-active {
  background: linear-gradient(135deg, #ff3366, #e60023);
  color: white;
  transform: translateX(5px);
  box-shadow: 0 6px 18px rgba(230, 0, 35, 0.25);
}

.drawer-footer {
  padding: 25px 20px;
  border-top: 1px solid var(--border-color);
}

.btn-sair-drawer {
  width: 100%;
  padding: 14px;
  background: #3d0a1b;
  color: white;
  border: none;
  border-radius: 14px;
  font-weight: 700;
  cursor: pointer;
}

.drawer-overlay {
  position: fixed;
  inset: 0;
  background: rgba(61, 10, 27, 0.3);
  backdrop-filter: blur(4px);
  z-index: 1000;
}

.page-fade-enter-active, .page-fade-leave-active {
  transition: opacity 0.25s ease, transform 0.25s ease;
}
.page-fade-enter-from { opacity: 0; transform: translateY(10px); }
.page-fade-leave-to { opacity: 0; transform: translateY(-10px); }
</style>