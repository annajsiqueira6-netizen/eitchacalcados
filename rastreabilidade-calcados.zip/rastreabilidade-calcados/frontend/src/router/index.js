import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import Lotes from '../views/Lotes.vue'
import Leitor from '../views/Leitor.vue'
import Login from '../views/Login.vue'
import Usuarios from '../views/Usuarios.vue'

const routes = [
  { path: '/', component: Dashboard },
  { path: '/lotes', component: Lotes },
  { path: '/leitor', component: Leitor },
  { path: '/login', component: Login },
  { path: '/usuarios', component: Usuarios }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router