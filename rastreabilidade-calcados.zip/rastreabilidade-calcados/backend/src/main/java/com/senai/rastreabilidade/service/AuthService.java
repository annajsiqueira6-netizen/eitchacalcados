package com.senai.rastreabilidade.service;

import com.senai.rastreabilidade.dto.Dtos.*;
import com.senai.rastreabilidade.model.Usuario;
import com.senai.rastreabilidade.repository.UsuarioRepository;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AuthService {
    private final UsuarioRepository repo;
    private final BCryptPasswordEncoder enc = new BCryptPasswordEncoder();
    private final Map<String, Long> tokens = new ConcurrentHashMap<>();

    public AuthService(UsuarioRepository repo) { this.repo = repo; }

    public LoginResponse login(LoginRequest r) {
        Usuario u = repo.findByEmail(r.email())
            .filter(Usuario::isAtivo)
            .filter(x -> enc.matches(r.senha(), x.getSenhaHash()))
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.UNAUTHORIZED, "E-mail ou senha invalidos"));
        String token = UUID.randomUUID().toString();
        tokens.put(token, u.getId());
        return new LoginResponse(token, u.getNome(), u.getPerfil().name());
    }

    public Optional<Usuario> porToken(String token) {
        return Optional.ofNullable(tokens.get(token)).flatMap(repo::findById);
    }

    public String hash(String senha) { return enc.encode(senha); }
}
