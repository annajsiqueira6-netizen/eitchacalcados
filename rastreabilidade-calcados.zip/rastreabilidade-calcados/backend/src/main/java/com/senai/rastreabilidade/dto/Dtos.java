package com.senai.rastreabilidade.dto;

import com.senai.rastreabilidade.model.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class Dtos {
    public record LoginRequest(@NotBlank String email, @NotBlank String senha) { }
    public record LoginResponse(String token, String nome, String perfil) { }

    public record LoteRequest(@NotBlank String modelo,
                              @Min(1) int quantidade,
                              @NotNull @DecimalMin("0.0") BigDecimal valorUnitario,
                              @NotNull Long bancaId) { }

    public record PerdaRequest(@NotNull TipoPerda tipo,
                               @Min(1) int quantidade,
                               String observacao) { }

    public record LoteResponse(Long id, String codigo, String modelo, int quantidade,
                               BigDecimal valorUnitario, String banca, StatusLote status,
                               int totalPerdas, BigDecimal valorDevido, Long cicloMinutos,
                               LocalDateTime criadoEm) { }

    public record MovResponse(String lote, StatusLote statusAnterior, StatusLote statusNovo,
                              String usuario, LocalDateTime dataHora, String observacao) { }

    public record DashboardResponse(long total, Map<String, Long> porStatus,
                                    long totalPerdas, BigDecimal valorDevido,
                                    double cicloMedioMinutos, List<MovResponse> ultimas) { }
}
