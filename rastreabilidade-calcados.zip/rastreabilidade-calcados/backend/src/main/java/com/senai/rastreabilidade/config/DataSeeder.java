package com.senai.rastreabilidade.config;

import com.senai.rastreabilidade.model.*;
import com.senai.rastreabilidade.repository.*;
import com.senai.rastreabilidade.service.AuthService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Cria usuarios e bancas de exemplo na primeira execucao (senha: 123456). */
@Component
public class DataSeeder implements CommandLineRunner {
    private final UsuarioRepository usuarios;
    private final BancaRepository bancas;
    private final AuthService auth;

    public DataSeeder(UsuarioRepository usuarios, BancaRepository bancas, AuthService auth) {
        this.usuarios = usuarios; this.bancas = bancas; this.auth = auth;
    }

    @Override
    public void run(String... args) {
        if (usuarios.count() == 0) {
            usuarios.save(novo("Gestor SENAI", "gestor@senai.com", Perfil.GESTOR));
            usuarios.save(novo("Operador SENAI", "operador@senai.com", Perfil.OPERADOR));
        }
        if (bancas.count() == 0) {
            bancas.save(banca("Banca Silva", "Sr. Silva"));
            bancas.save(banca("Banca Dona Rita", "Rita Souza"));
            bancas.save(banca("Banca Tres Irmaos", "Carlos Pereira"));
        }
    }

    private Usuario novo(String nome, String email, Perfil perfil) {
        Usuario u = new Usuario();
        u.setNome(nome); u.setEmail(email); u.setPerfil(perfil);
        u.setSenhaHash(auth.hash("123456")); u.setAtivo(true);
        return u;
    }

    private Banca banca(String nome, String responsavel) {
        Banca b = new Banca();
        b.setNome(nome); b.setResponsavel(responsavel);
        b.setCidade("Nova Serrana"); b.setAtiva(true);
        return b;
    }
}
