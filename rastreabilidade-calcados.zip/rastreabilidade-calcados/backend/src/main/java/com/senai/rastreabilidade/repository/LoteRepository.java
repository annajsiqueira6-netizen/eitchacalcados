package com.senai.rastreabilidade.repository;

import com.senai.rastreabilidade.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;


public interface LoteRepository extends JpaRepository<Lote, Long> {
    Optional<Lote> findByCodigo(String codigo);
    long countByStatus(StatusLote status);
}
