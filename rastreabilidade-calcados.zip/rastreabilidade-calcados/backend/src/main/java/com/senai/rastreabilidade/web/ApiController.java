package com.senai.rastreabilidade.web;

import com.senai.rastreabilidade.dto.Dtos.*;
import com.senai.rastreabilidade.model.*;
import com.senai.rastreabilidade.repository.BancaRepository;
import com.senai.rastreabilidade.service.*;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final AuthService auth;
    private final LoteService service;
    private final BancaRepository bancas;

    public ApiController(AuthService auth, LoteService service, BancaRepository bancas) {
        this.auth = auth; this.service = service; this.bancas = bancas;
    }

    @PostMapping("/auth/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest r) { return auth.login(r); }

    @GetMapping("/bancas")
    public List<Banca> listarBancas() { return bancas.findAll(); }

    @PostMapping("/bancas")
    public Banca novaBanca(@RequestBody Banca b, @RequestAttribute("usuario") Usuario u) {
        exigeGestor(u);
        b.setId(null); b.setAtiva(true);
        return bancas.save(b);
    }

    @GetMapping("/lotes")
    public List<LoteResponse> listarLotes() { return service.listar(); }

    @PostMapping("/lotes")
    public LoteResponse criarLote(@Valid @RequestBody LoteRequest r,
                                  @RequestAttribute("usuario") Usuario u) {
        exigeGestor(u);
        return service.criar(r, u);
    }

    @GetMapping("/lotes/{codigo}")
    public LoteResponse obter(@PathVariable String codigo) { return service.obter(codigo); }

    @PostMapping("/lotes/{codigo}/scan")
    public LoteResponse scan(@PathVariable String codigo,
                             @RequestAttribute("usuario") Usuario u) {
        return service.lerQr(codigo, u);
    }

    @PostMapping("/lotes/{codigo}/perdas") @ResponseStatus(HttpStatus.CREATED)
    public void perda(@PathVariable String codigo, @Valid @RequestBody PerdaRequest r,
                      @RequestAttribute("usuario") Usuario u) {
        service.registrarPerda(codigo, r, u);
    }

    @GetMapping("/lotes/{codigo}/movimentacoes")
    public List<MovResponse> historico(@PathVariable String codigo) {
        return service.historico(codigo);
    }

    @GetMapping("/dashboard")
    public DashboardResponse dashboard() { return service.dashboard(); }

    private void exigeGestor(Usuario u) {
        if (u.getPerfil() != Perfil.GESTOR)
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Apenas o gestor pode isso");
    }
}
