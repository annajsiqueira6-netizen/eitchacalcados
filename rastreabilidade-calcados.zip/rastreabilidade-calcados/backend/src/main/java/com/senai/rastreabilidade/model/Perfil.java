package com.senai.rastreabilidade.model;

public enum Perfil {
    GESTOR,
    OPERADOR
}