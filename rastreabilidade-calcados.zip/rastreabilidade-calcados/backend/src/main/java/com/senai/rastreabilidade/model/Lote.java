package com.senai.rastreabilidade.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "lotes") @Getter @Setter
public class Lote {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 36)
    private String codigo;
    private String modelo;
    private int quantidade;
    private BigDecimal valorUnitario;
    @ManyToOne(optional = false) @JoinColumn(name = "banca_id")
    private Banca banca;
    @ManyToOne(optional = false) @JoinColumn(name = "criado_por")
    private Usuario criadoPor;
    @Enumerated(EnumType.STRING)
    private StatusLote status;
    private LocalDateTime criadoEm;
    private LocalDateTime enviadoEm;
    private LocalDateTime recebidoEm;
    private LocalDateTime concluidoEm;
}
