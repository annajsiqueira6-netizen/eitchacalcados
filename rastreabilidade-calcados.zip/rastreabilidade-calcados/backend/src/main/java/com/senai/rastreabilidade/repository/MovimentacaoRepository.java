package com.senai.rastreabilidade.repository;

import com.senai.rastreabilidade.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;


public interface MovimentacaoRepository extends JpaRepository<Movimentacao, Long> {
    List<Movimentacao> findByLoteIdOrderByDataHoraDesc(Long loteId);
    List<Movimentacao> findTop10ByOrderByDataHoraDesc();
}
