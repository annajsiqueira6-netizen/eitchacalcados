package com.senai.rastreabilidade.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "movimentacoes") @Getter @Setter
public class Movimentacao {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "lote_id")
    private Lote lote;
    @ManyToOne(optional = false) @JoinColumn(name = "usuario_id")
    private Usuario usuario;
    @Enumerated(EnumType.STRING)
    private StatusLote statusAnterior;
    @Enumerated(EnumType.STRING)
    private StatusLote statusNovo;
    private LocalDateTime dataHora;
    private String observacao;
}
