package com.senai.rastreabilidade.repository;

import com.senai.rastreabilidade.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;


public interface PerdaRepository extends JpaRepository<Perda, Long> {
    @Query("select coalesce(sum(p.quantidade), 0) from Perda p where p.lote.id = :id")
    long somaPorLote(@Param("id") Long id);

    @Query("select coalesce(sum(p.quantidade), 0) from Perda p")
    long somaTotal();
}
