package com.senai.rastreabilidade.model;

public enum StatusLote {
    CRIADO, ENVIADO_BANCA, EM_PROCESSAMENTO, CONCLUIDO;

    /** Regra de negocio: cada leitura do QR Code avanca UM passo no fluxo. */
    public StatusLote proximo() {
        return switch (this) {
            case CRIADO -> ENVIADO_BANCA;
            case ENVIADO_BANCA -> EM_PROCESSAMENTO;
            case EM_PROCESSAMENTO -> CONCLUIDO;
            case CONCLUIDO -> throw new IllegalStateException("Lote ja concluido");
        };
    }
}
