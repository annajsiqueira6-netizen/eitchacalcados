package com.senai.rastreabilidade.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name = "bancas") @Getter @Setter
public class Banca {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private String responsavel;
    private String telefone;
    private String cidade;
    private boolean ativa;
}
