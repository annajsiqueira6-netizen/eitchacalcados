package com.senai.rastreabilidade.service;

import com.senai.rastreabilidade.dto.Dtos.*;
import com.senai.rastreabilidade.model.*;
import com.senai.rastreabilidade.repository.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LoteService {
    private final LoteRepository lotes;
    private final BancaRepository bancas;
    private final MovimentacaoRepository movs;
    private final PerdaRepository perdas;

    public LoteService(LoteRepository lotes, BancaRepository bancas,
                       MovimentacaoRepository movs, PerdaRepository perdas) {
        this.lotes = lotes; this.bancas = bancas; this.movs = movs; this.perdas = perdas;
    }

    /** RF01: cria o lote e gera o codigo unico que vira QR Code. */
    @Transactional
    public LoteResponse criar(LoteRequest r, Usuario u) {
        Banca b = bancas.findById(r.bancaId())
            .orElseThrow(() -> new NoSuchElementException("Banca nao encontrada"));
        Lote l = new Lote();
        l.setCodigo(UUID.randomUUID().toString());
        l.setModelo(r.modelo());
        l.setQuantidade(r.quantidade());
        l.setValorUnitario(r.valorUnitario());
        l.setBanca(b);
        l.setCriadoPor(u);
        l.setStatus(StatusLote.CRIADO);
        l.setCriadoEm(LocalDateTime.now());
        lotes.save(l);
        registrar(l, null, StatusLote.CRIADO, u, "Lote criado");
        return toResponse(l);
    }

    /** RF02: leitura do QR Code = avanca um status e grava a movimentacao. */
    @Transactional
    public LoteResponse lerQr(String codigo, Usuario u) {
        Lote l = buscar(codigo);
        StatusLote antigo = l.getStatus();
        StatusLote novo = antigo.proximo();          // lanca erro se ja concluido
        LocalDateTime agora = LocalDateTime.now();
        switch (novo) {
            case ENVIADO_BANCA -> l.setEnviadoEm(agora);
            case EM_PROCESSAMENTO -> l.setRecebidoEm(agora);
            case CONCLUIDO -> l.setConcluidoEm(agora);
            default -> { }
        }
        l.setStatus(novo);
        lotes.save(l);
        registrar(l, antigo, novo, u, "Leitura de QR Code");
        return toResponse(l);
    }

    /** RF03: perdas so podem ser registradas com o lote Em Processamento. */
    @Transactional
    public void registrarPerda(String codigo, PerdaRequest r, Usuario u) {
        Lote l = buscar(codigo);
        if (l.getStatus() != StatusLote.EM_PROCESSAMENTO)
            throw new IllegalStateException(
                "Perdas so podem ser registradas com o lote Em Processamento");
        if (perdas.somaPorLote(l.getId()) + r.quantidade() > l.getQuantidade())
            throw new IllegalArgumentException("Perdas maiores que a quantidade do lote");
        Perda p = new Perda();
        p.setLote(l); p.setUsuario(u); p.setTipo(r.tipo());
        p.setQuantidade(r.quantidade()); p.setObservacao(r.observacao());
        p.setRegistradaEm(LocalDateTime.now());
        perdas.save(p);
    }

    @Transactional(readOnly = true)
    public List<LoteResponse> listar() {
        return lotes.findAll(Sort.by(Sort.Direction.DESC, "criadoEm"))
                    .stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public LoteResponse obter(String codigo) { return toResponse(buscar(codigo)); }

    @Transactional(readOnly = true)
    public List<MovResponse> historico(String codigo) {
        Lote l = buscar(codigo);
        return movs.findByLoteIdOrderByDataHoraDesc(l.getId())
                   .stream().map(this::toMov).toList();
    }

    /** RF04: dados do painel gerencial. */
    @Transactional(readOnly = true)
    public DashboardResponse dashboard() {
        Map<String, Long> porStatus = new LinkedHashMap<>();
        for (StatusLote s : StatusLote.values())
            porStatus.put(s.name(), lotes.countByStatus(s));
        BigDecimal devido = BigDecimal.ZERO;
        long somaCiclo = 0, concluidos = 0;
        List<Lote> todos = lotes.findAll();
        for (Lote l : todos) {
            LoteResponse r = toResponse(l);
            devido = devido.add(r.valorDevido());
            if (r.cicloMinutos() != null) { somaCiclo += r.cicloMinutos(); concluidos++; }
        }
        double media = concluidos == 0 ? 0 : (double) somaCiclo / concluidos;
        var ultimas = movs.findTop10ByOrderByDataHoraDesc().stream().map(this::toMov).toList();
        return new DashboardResponse(todos.size(), porStatus, perdas.somaTotal(),
                                     devido, media, ultimas);
    }

    private Lote buscar(String codigo) {
        return lotes.findByCodigo(codigo)
            .orElseThrow(() -> new NoSuchElementException("Lote nao encontrado"));
    }

    private void registrar(Lote l, StatusLote ant, StatusLote novo, Usuario u, String obs) {
        Movimentacao m = new Movimentacao();
        m.setLote(l); m.setUsuario(u);
        m.setStatusAnterior(ant); m.setStatusNovo(novo);
        m.setDataHora(LocalDateTime.now()); m.setObservacao(obs);
        movs.save(m);
    }

    private LoteResponse toResponse(Lote l) {
        int perdidas = (int) perdas.somaPorLote(l.getId());
        BigDecimal devido = BigDecimal.ZERO;
        Long ciclo = null;
        if (l.getStatus() == StatusLote.CONCLUIDO) {
            devido = l.getValorUnitario()
                      .multiply(BigDecimal.valueOf(l.getQuantidade() - perdidas));
            ciclo = Duration.between(l.getEnviadoEm(), l.getConcluidoEm()).toMinutes();
        }
        return new LoteResponse(l.getId(), l.getCodigo(), l.getModelo(), l.getQuantidade(),
            l.getValorUnitario(), l.getBanca().getNome(), l.getStatus(), perdidas,
            devido, ciclo, l.getCriadoEm());
    }

    private MovResponse toMov(Movimentacao m) {
        return new MovResponse(m.getLote().getModelo(), m.getStatusAnterior(),
            m.getStatusNovo(), m.getUsuario().getNome(), m.getDataHora(), m.getObservacao());
    }
}
