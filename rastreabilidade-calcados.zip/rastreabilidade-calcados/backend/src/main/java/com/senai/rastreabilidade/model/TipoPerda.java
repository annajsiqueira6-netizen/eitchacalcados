package com.senai.rastreabilidade.model;
public enum TipoPerda { DANIFICADA, EXTRAVIADA, DEFEITO_FABRICACAO }
