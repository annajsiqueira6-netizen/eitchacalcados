package com.senai.rastreabilidade;

import static org.junit.jupiter.api.Assertions.*;

import com.senai.rastreabilidade.model.StatusLote;
import org.junit.jupiter.api.Test;

class StatusLoteTest {
    @Test
    void fluxoCompletoDoLote() {
        assertEquals(StatusLote.ENVIADO_BANCA, StatusLote.CRIADO.proximo());
        assertEquals(StatusLote.EM_PROCESSAMENTO, StatusLote.ENVIADO_BANCA.proximo());
        assertEquals(StatusLote.CONCLUIDO, StatusLote.EM_PROCESSAMENTO.proximo());
    }

    @Test
    void loteConcluidoNaoAvanca() {
        assertThrows(IllegalStateException.class, StatusLote.CONCLUIDO::proximo);
    }
}
