CREATE DATABASE IF NOT EXISTS rastreabilidade
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rastreabilidade;

CREATE TABLE usuarios (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  email       VARCHAR(120) NOT NULL UNIQUE,
  senha_hash  VARCHAR(100) NOT NULL,
  perfil      VARCHAR(20)  NOT NULL DEFAULT 'OPERADOR',   -- GESTOR | OPERADOR
  ativo       BOOLEAN      NOT NULL DEFAULT TRUE,
  criado_em   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE bancas (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  responsavel VARCHAR(100),
  telefone    VARCHAR(20),
  cidade      VARCHAR(80),
  ativa       BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE lotes (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  codigo         VARCHAR(36)   NOT NULL UNIQUE,        -- conteudo do QR Code
  modelo         VARCHAR(100)  NOT NULL,
  quantidade     INT           NOT NULL,
  valor_unitario DECIMAL(10,2) NOT NULL,
  banca_id       BIGINT        NOT NULL,
  criado_por     BIGINT        NOT NULL,
  status         VARCHAR(20)   NOT NULL DEFAULT 'CRIADO',
  criado_em      DATETIME      NOT NULL,
  enviado_em     DATETIME      NULL,
  recebido_em    DATETIME      NULL,
  concluido_em   DATETIME      NULL,
  CONSTRAINT fk_lote_banca   FOREIGN KEY (banca_id)   REFERENCES bancas(id),
  CONSTRAINT fk_lote_usuario FOREIGN KEY (criado_por) REFERENCES usuarios(id),
  INDEX idx_lote_status (status)
);

CREATE TABLE movimentacoes (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  lote_id         BIGINT      NOT NULL,
  usuario_id      BIGINT      NOT NULL,
  status_anterior VARCHAR(20) NULL,
  status_novo     VARCHAR(20) NOT NULL,
  data_hora       DATETIME    NOT NULL,
  observacao      VARCHAR(255),
  CONSTRAINT fk_mov_lote    FOREIGN KEY (lote_id)    REFERENCES lotes(id),
  CONSTRAINT fk_mov_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE perdas (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  lote_id       BIGINT      NOT NULL,
  usuario_id    BIGINT      NOT NULL,
  tipo          VARCHAR(30) NOT NULL,   -- DANIFICADA | EXTRAVIADA | DEFEITO_FABRICACAO
  quantidade    INT         NOT NULL,
  observacao    VARCHAR(255),
  registrada_em DATETIME    NOT NULL,
  CONSTRAINT fk_perda_lote    FOREIGN KEY (lote_id)    REFERENCES lotes(id),
  CONSTRAINT fk_perda_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
